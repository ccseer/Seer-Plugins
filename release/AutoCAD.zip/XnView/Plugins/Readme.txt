CS_CGM.DLL, CS_DWG.DLL, CS_DXF.DLL, CS_HPGL.DLL,
CS_SVG.DLL (CS_xxx.DLL) and CADImage.DLL plugins.

1. Installation:
   Copy CS_xxx.DLL or CADImage.DLL to Viewer\PlugIns\ directory.
   For example  C:\Program Files\IrfanView\PlugIns\CS_DWG.DLL

!!! Pay attention to IrfanView and XnView do not uses CS_xxx.DLL if
  CADImage.DLL is in plugins directory. If you need to use CS_xxx.DLL
  plugin please remove CADImage.DLL, if exists, from plugins folder.

2. Managing:
   Setup CS_Manager.exe for registration dialog calling, changing image size 
   of drawings and color/black-white mode switching.

3. Registration:
3.1. Buy license from http://www.cadsofttools.com/en/documents/order.html page			
3.2. Load CS_Manager
3.3. Press CS_xxx button to show registration dialog for CS_xxx.DLL plugin or 
     CADImage button to show registration dialog for CADImage.DLL plugin.


You can download all CS_xxx.DLL plugins from the links:

http://www.cadsofttools.com/download/cs_xxx.zip
http://www.cadsofttools.com/download/plugins.zip
http://www.cadsofttools.com/download/allplugins.zip

Use CADImage.DLL plugin if you need to register all five formats.
Download CADImage.DLL plugin:

http://www.cadsofttools.com/download/cadimageplugin.zip
http://www.cadsofttools.com/download/plugins.zip
http://www.cadsofttools.com/download/allplugins.zip


Thank you for using CADSoftTools plugins!